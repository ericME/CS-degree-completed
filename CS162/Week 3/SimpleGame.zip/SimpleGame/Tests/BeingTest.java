import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class BeingTest
{
	private Being aBeing;
	private static final int HEALTH = 85;
	private static final int ATTACK = 7;
	
	@Before
	public void setUp() {
		aBeing = new Being(HEALTH, ATTACK);
	}
	
	/** Tests that a being has been created with the proper health value*/
	@Test
	public void testBeingStartingHealth()
	{
		assertEquals(HEALTH,aBeing.getHealth());
	}
	
	/** Tests that a being has been created with the proper attack value*/
	@Test
	public void testBeingStartingAttack()
	{
		assertEquals(ATTACK,aBeing.getAttack());
	}
	
	/** Tests that a being's max health goes up properly from experience*/
	@Test
	public void testXPIncreasesMaxHealth()
	{
		int increasedExperience = 4;
		int preExperienceMaxHealth = aBeing.getMaxHealth();
		
		aBeing.addExperience(increasedExperience);
		int postExperienceMaxHealth = aBeing.getMaxHealth();
		
		assertEquals(postExperienceMaxHealth - increasedExperience, preExperienceMaxHealth);
	}
	
	/** Tests that rest the rest method recovers health when damaged to begin with*/
	@Test
	public void testRestSimple()
	{
		
		int damage = 17;
		aBeing.takeDamage(damage);
		int healingAmount;
		
		int preRestHealth = aBeing.getHealth();
		healingAmount = aBeing.rest();
		int postRestHealth = aBeing.getHealth();
		
		assertTrue(postRestHealth >= preRestHealth);
		assertTrue(preRestHealth + healingAmount >= postRestHealth);
	}
	
	/** Tests that rest the rest method recovers heath in several random cases*/
	@Test
	public void testRestRandom()
	{
		int damage;
		int damageRange = 50;
		
		for(int i = 0; i < 20; i++)
		{
			damage = (int)Math.random() * damageRange;
			aBeing.takeDamage(damage);
			
			int preRestHealth = aBeing.getHealth();
			aBeing.rest();
			int postRestHealth = aBeing.getHealth();
			
			assertTrue(postRestHealth >= preRestHealth);
		}
	}
	
	/** Tests that a being takes the proper amount of damage*/
	@Test
	public void testTakeDamage()
	{
		int damage = 12;
		int preDamageHealth = aBeing.getHealth();
		aBeing.takeDamage(damage);
		
		assertEquals(aBeing.getHealth()+damage,preDamageHealth);
		assertTrue(preDamageHealth > aBeing.getHealth());
	}
	
	/** Tests that a being's attack increases with experience*/
	@Test
	public void testXPIncreasesAttack()
	{
		int increasedExperience = 7;
		int preExperienceAttack = aBeing.getAttack();
		
		aBeing.addExperience(increasedExperience);
		int postExperienceAttack = aBeing.getAttack();
		
		assertEquals(postExperienceAttack - (increasedExperience / 3), preExperienceAttack);
	}
	
	/** Tests that a being's experience increase properly with addExperience*/
	@Test
	public void testAddExperience()
	{
		int increasedExperience = 25;
		int preIncreasedExperience = aBeing.getExperience();
		
		aBeing.addExperience(increasedExperience);
		int postIncreasedExperience = aBeing.getExperience();
		
		assertEquals(postIncreasedExperience - increasedExperience, preIncreasedExperience);
	}
	
	/** Tests that a being's age increases properly with addAge*/
	@Test
	public void testAddAge()
	{
		int increasedAge = 2;
		int preAgedAge = aBeing.getAge();
		
		aBeing.addAge(increasedAge);
		int postAgedAge = aBeing.getAge();
		
		assertEquals(postAgedAge - increasedAge, preAgedAge);
	}
	
}
