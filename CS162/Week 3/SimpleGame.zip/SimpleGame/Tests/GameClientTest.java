import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/** Note that this class is poorly setup for black box testing, it should be
 * 	reorganized with more methods for better testing of its complex components*/
public class GameClientTest
{

	GameClient aGameClient;
	
	@Before
	public void setUp()
	{	
		//no setup without user input possible with this class
	}

	/** Note that no tests can be made due to there only being void return type methods in this class*/
	
}
