import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


/** Note that this class is poorly setup for black box testing, it should be
 * 	reorganized with more methods for better testing of its complex components*/
public class AdventureTest
{

	Adventure anAdventure;
	private static final int HEALTH = 44;
	private static final int ATTACK = 5;
	
	@Before
	public void setUp()
	{	
		anAdventure = new Adventure(HEALTH, ATTACK);
	}

	/** Note that no tests can be made due to there only being void return type methods in this class*/
	
}
