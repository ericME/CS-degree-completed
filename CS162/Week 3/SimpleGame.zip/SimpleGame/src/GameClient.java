//Simple game client

import java.util.Scanner;

public class GameClient
{	
	private Scanner input;
	
	public GameClient()
	{
		boolean newGame = true;
		input = new Scanner(System.in);
		
		while(newGame)
		{
			Adventure game = new Adventure(100, 10);
			System.out.printf("I hope you enjoyed your adventure, would you like to try another (yes/no)?");
			String inStr = input.next();
			inStr = validateContinueInput(inStr);
			
			if(inStr.equals("no") )
				newGame = false;
		}
	}
	
	public static void main(String[] args)
	{
		GameClient game = new GameClient();
	}
	
	private String validateContinueInput(String str)
	{
		
		String returnedValue = "bad input";
		
		if (str.toLowerCase().equals("y") || str.toLowerCase().equals("yes") )
			returnedValue = "yes";
		else if (str.toLowerCase().equals("n") || str.toLowerCase().equals("no") )
			returnedValue = "no";
		
		while(returnedValue.equals("bad input"))
		{
			if (str.toLowerCase().equals("y") || str.toLowerCase().equals("yes") )
				returnedValue = "yes";
			else if (str.toLowerCase().equals("n") || str.toLowerCase().equals("no") )
				returnedValue = "no";
			
			System.out.printf("I'm sorry, I did not understand your input, I was expecting to read a yes or no");
			returnedValue = input.next();
		}
		
		return returnedValue;
	}
}