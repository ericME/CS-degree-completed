import java.util.Scanner;

public class Adventure
{
	private Being hero;
	private Scanner input = new Scanner(System.in);
	
	public Adventure(int heroHealth, int heroAttack)
	{
		hero = new Being(heroHealth,heroAttack);
		
		System.out.printf("You are a hero of legend, wandering the countryside fighting dangerous creatures to protect the country you call home.\n");
		System.out.printf("You have %d health to survive encounters with wild creatures and %d attack.\n", hero.getHealth(), hero.getAttack());
		startAdventure();
	}
	
	public void startAdventure()
	{	
		boolean retire = false;
		while(hero.getHealth() > 0 && !retire)
		{
			hero.addAge(1);
			System.out.printf("You are wandering the land on day %d of your adventure with %d health, %d attack, and %d experience, what do you do?\n", hero.getAge(), hero.getHealth(), hero.getAttack(), hero.getExperience());
			System.out.printf("[s]earch for a dangerous creature\n" + 
					"[r]est to recover health\n" +
					"[q]uit the adventuring life and retire\n");
			
			String action = input.next();
			action = validateMenuInput(action);
			
			if(action.equals("search"))
			{
				encounter();
			}
			else if(action.equals("rest"))
			{
				int healingAmount = hero.rest();
				System.out.printf("You rest, recovering %d health.\n", healingAmount, hero.getHealth());
			}
			else if(action.equals("retire"))
			{
				retire = true;
				System.out.printf("You retire, leaving the protection of your country to more capable hands\n");
			}
			else
			{
				System.out.printf("I am not sure how you got here, but you need to leave and contact the programmer of this world");
			}
		} //end primary adventure loop
		if(hero.getHealth() <= 0)
		{
			System.out.printf("Regrettably, you have died from a dangerous creature.\n");
		}
		System.out.printf("You survived for %d day(s) and defeated %d dangerous creature(s)\n", hero.getAge(), hero.getExperience());
	}
	
	private void encounter()
	{
		int creatureHealth = (int)Math.random() * hero.getExperience() + 20;
		int creatureAttack = (int)Math.random() * (hero.getExperience() / 3) + 5;
		Being creature = new Being(creatureHealth, creatureAttack);
		
		boolean escaped = false;
		
		while( hero.getHealth() > 0 && creature.getHealth() > 0 && !escaped)
		{
			System.out.printf("\n--------------------------------------------------------------\n" +
					"You are fighting a dangerous creature!\nWhat do you do?\n");
			System.out.printf("[a]ttack the dangerous creature\n" + 
					"[r]etreat in hopes of getting away from the dangerous creature\n" +
					"-------------------------------------------------------------\n");
			
			String action = input.next();
			action = validateEncounterInput(action);
			
			if(action.equals("attack"))
			{
				if(Math.random() < 0.1)
				{
					System.out.printf("Your attack narrowly misses the dangerous creature!\n");
				}
				else
				{
					int herosAttack = (int)(hero.getAttack() * ( 1 + Math.random()) );
					creature.takeDamage(herosAttack);
					System.out.printf("You hit the creature, dealing %d damage\n", herosAttack);
				}
				
			}
			else if(action.equals("retreat"))
			{
				if(Math.random() < 0.5)
				{
					System.out.printf("You safely escape from the dangerous creature to fight another day!\n");
					escaped = true;
				}
				else
				{
					System.out.printf("You try to run, but the dangerous creature catches you trying to retreat!\n");
				}
			}
			
			if(creature.getHealth() > 0) //creature is still alive so it attempts to attack the hero
			{
				if(Math.random() < 0.1)
				{
					System.out.printf("The creature's attack narrowly misses you!\n");
				}
				else
				{
					int creaturesAttack = (int)(creature.getAttack() * ( 1 + Math.random() ));
					hero.takeDamage(creaturesAttack);
					System.out.printf("The creature hits you, dealing %d damage, leaving you with %d health\n", creaturesAttack, hero.getHealth());
				}
			}
		}//end primary encounter while loop
		
		//make sure the reason for leaving loop is defeating creature
		if(creature.getHealth() <= 0)
		{
			System.out.printf("You have made your country a little safer by" +
					" defeating a weaker dangerous creature, and learn a little more" +
					" about how to fight them\n");
			hero.addExperience(1);
		}
	}
	
	private String validateMenuInput(String str)
	{
		String returnedValue = "bad input";
		
		if (str.equalsIgnoreCase("s") || str.equalsIgnoreCase("search"))
		{
			returnedValue = "search";
		}
		else if (str.equalsIgnoreCase("r") || str.equalsIgnoreCase("rest"))
		{
			returnedValue = "rest";
		}
		else if (str.equalsIgnoreCase("q") || str.equalsIgnoreCase("quit") || str.equalsIgnoreCase("retire"))
		{
			returnedValue = "retire";
		}
		
		while(returnedValue.equals("bad input"))
		{	
			System.out.printf("I'm sorry, I did not understand your input, I was expecting to see s for search or r for rest\n");
			str = input.next();
			
			if (str.equalsIgnoreCase("s") || str.equalsIgnoreCase("search"))
			{
				returnedValue = "search";
			}
			else if (str.equalsIgnoreCase("r") || str.equalsIgnoreCase("rest"))
			{
				returnedValue = "rest";
			}
			else if (str.equalsIgnoreCase("q") || str.equalsIgnoreCase("quit") || str.equalsIgnoreCase("retire"))
			{
				returnedValue = "retire";
			}
		}
		return returnedValue;
	}
	
	private String validateEncounterInput(String str)
	{
		String returnedValue = "bad input";
		
		if(str.equalsIgnoreCase("attack") || str.equalsIgnoreCase("a"))
		{
			returnedValue = "attack";
		}
		else if(str.equalsIgnoreCase("retreat") || str.equalsIgnoreCase("r"))
		{
			returnedValue = "retreat";
		}
		
		while(returnedValue.equals("bad input"))
		{	
			System.out.printf("I'm sorry, I did not understand your input, I was expecting to see a for attack or r for retreat\n");
			str = input.next();
			
			if(str.equalsIgnoreCase("attack") || str.equalsIgnoreCase("a"))
			{
				returnedValue = "attack";
			}
			else if(str.equalsIgnoreCase("retreat") || str.equalsIgnoreCase("r"))
			{
				returnedValue = "retreat";
			}
		}
		
		return returnedValue;
	}
}
