//sample class for a hero object in a simple game

public class Being
{
	private int health;
	private int attack;
	private int experience = 0;
	private int age = 0;
	
	public Being (int startingHealth, int startingAttack)
	{
		health = startingHealth;
		attack = startingAttack;
	}
	
	public int getHealth()
	{
		return health;
	}
	
	public int getMaxHealth()
	{
		return (100 + experience);
	}
	
	public int rest()
	{
		int maxHealth = getMaxHealth();
		int healingAmount = (int)((maxHealth / 10.0) * (1 + Math.random()));
		if((healingAmount + health) > maxHealth)
			healingAmount = maxHealth - health; 
		health += healingAmount;
		return healingAmount;
	}
	
	public void takeDamage(int damage)
	{
		health -= damage;
	}
	
	public int getAttack()
	{
		return attack + experience / 3;
	}	
	
	public int getExperience()
	{
		return experience;
	}	
	
	public void addExperience(int addedExperience)
	{
		experience += addedExperience;
	}
	
	public int getAge()
	{
		return age;
	}
	
	public void addAge(int addedAge)
	{
		age += addedAge;
	}
}
