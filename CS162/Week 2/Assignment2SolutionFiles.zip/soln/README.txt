Files in this directory are for both the solution and the example applet.
Assignment3ExampleLaunchr.java and BattleshipBoardGUIJInternalFrame.java are used for the applet,
and the rest are part of the solution.

Javid
