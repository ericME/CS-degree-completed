import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;


public class ImageViewer extends JFrame {

	public ImageViewer() {
		setTitle(???);
		setSize(???);
	}

	public static void main (String [] args) {
		JFrame gui = new ImageViewer();
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gui.setVisible(true);
	}
}
