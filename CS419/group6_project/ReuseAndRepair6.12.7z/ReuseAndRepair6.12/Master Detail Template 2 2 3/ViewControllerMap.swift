//
//  ViewControllerMap.swift
//  Master Detail Template
//
//  Created by Lacie Wilson on 5/28/15.
//  Copyright (c) 2015 lacieapp. All rights reserved.
//

import UIKit
import MapKit
import CoreData


class ViewControllerMap: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet var map: MKMapView!
    
    var manager: CLLocationManager!
    var managedObjectContext: NSManagedObjectContext? = nil
   
    var currentAnnotation : MKAnnotation!
    
    var receivedBusinessAddresses : [AnyObject] = []
    var receivedBusinessNames : [AnyObject] = []
    var receivedZip : [AnyObject] = []
    
    var businessName: String!
    
    //var businessAdd :String = ""
    //var businessPh : String = ""
    //var businessUr : String = ""
    //var businessHrs :String = ""
    
    var globalImageArray: [UIImage] = [
        UIImage(named: "pin1.png")!,
        UIImage(named: "pin2.png")!, UIImage(named: "pin3.png")!, UIImage(named: "pin4.png")!, UIImage(named: "pin5.png")!, UIImage(named: "pin6.png")!, UIImage(named: "pin7.png")!, UIImage(named: "pin8.png")!, UIImage(named: "pin9.png")!, UIImage(named: "pin10.png")!,  UIImage(named: "pin11.png")!,  UIImage(named: "pin12.png")!,  UIImage(named: "pin13.png")!,  UIImage(named: "pin14.png")!,  UIImage(named: "pin15.png")!,  UIImage(named: "pin16.png")!,  UIImage(named: "pin17.png")!,  UIImage(named: "pin18.png")!,  UIImage(named: "pin19.png")!,  UIImage(named: "pin20.png")!,  UIImage(named: "pin21.png")!,  UIImage(named: "pin22.png")!, UIImage(named: "pin23.png")!, UIImage(named: "pin24.png")!, UIImage(named: "pin25.png")!, UIImage(named: "pin26.png")!, UIImage(named: "pin27.png")!, UIImage(named: "pin28.png")!, UIImage(named: "pin29.png")!, UIImage(named: "pin30.png")!, UIImage(named: "pin31.png")!, UIImage(named: "pin32.png")!, UIImage(named: "pin33.png")!, UIImage(named: "pin34.png")!, UIImage(named: "pin35.png")!, UIImage(named: "pin36.png")!, UIImage(named: "pin37.png")!, UIImage(named: "pin38.png")!, UIImage(named: "pin39.png")!, UIImage(named: "pin40.png")!
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.addSubview(map)

        manager = CLLocationManager()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.requestWhenInUseAuthorization()
        manager.startUpdatingLocation()
    
        for var i = 0; i < receivedBusinessAddresses.count; i++ {
            let location = "\(receivedBusinessAddresses[i]) \(receivedZip[i])"
            let title = receivedBusinessNames[i] as! String
            let subtitle = ""
            var geocoder:CLGeocoder = CLGeocoder()
            var imageName = globalImageArray[i]
            geocoder.geocodeAddressString(location, completionHandler: {(placemarks, error) -> Void in
                
                if((error) != nil){
                    
                    println("Error", error)
                }
                    
                else if let placemark = placemarks?[0] as? CLPlacemark {
                    
                    var placemark:CLPlacemark = placemarks[0] as! CLPlacemark
                    var coordinate:CLLocationCoordinate2D = placemark.location.coordinate
                    
                    var annotation = CustomAnnotation(coordinate: coordinate, title: title, subtitle: subtitle)
                    annotation.image = imageName
                    self.map.addAnnotation(annotation)
                    
                    var destination: CLLocation = CLLocation(latitude: coordinate.latitude, longitude: coordinate.longitude)
                    
                    var locManager = CLLocationManager()
                    locManager.requestWhenInUseAuthorization()
                    
                    var currentLocation = CLLocation()
                    currentLocation = locManager.location
                    let distance = destination.distanceFromLocation(currentLocation)
                    let distanceInMiles = distance * 0.000621371
 
                }
                
            })
            
        }

        // Do any additional setup after loading the view.
    }
    
    
    func locationManager(manager: CLLocationManager!, didUpdateLocations locations: [AnyObject]!) {
        
        var userLocation: CLLocation = locations[0] as! CLLocation
        var latitude = userLocation.coordinate.latitude
        var longitude = userLocation.coordinate.longitude
        var coordinate = CLLocationCoordinate2DMake(latitude, longitude)
        

        //var latDelta: CLLocationDegrees = 1.0
        //var lonDelta: CLLocationDegrees = 1.0
        //var span: MKCoordinateSpan = MKCoordinateSpanMake(latDelta, lonDelta)
        //var region: MKCoordinateRegion = MKCoordinateRegionMake(coordinate, span)
        //self.map.setRegion(region, animated: true)
        
        self.map.showsUserLocation = true
        
    }
    
    func mapView(mapView: MKMapView!, didUpdateUserLocation
        userLocation: MKUserLocation!) {
            let userLocation = mapView.userLocation
            
            let region = MKCoordinateRegionMakeWithDistance(
                userLocation.location.coordinate, 2000, 2000)
            
            mapView.setRegion(region, animated: true)
    }
    
    
    func mapView(mapView: MKMapView!, annotationView view: MKAnnotationView!, calloutAccessoryControlTapped control: UIControl!) {
        if control == view.rightCalloutAccessoryView {

            businessName = view.annotation.title
          
            performSegueWithIdentifier("showBusinessButton", sender: self)
            
        }
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "showBusinessButton" {
            
            var destination = segue.destinationViewController as! MapBusinessTableView
            destination.receivedBusinessTitle = businessName
            destination.title = businessName
    }
    }
    
    func mapView(mapView: MKMapView!, viewForAnnotation annotation: MKAnnotation!) -> MKAnnotationView! {
        if !(annotation is CustomAnnotation) {
            return nil
        }
        
        let reuseId = "business"
        var anView = mapView.dequeueReusableAnnotationViewWithIdentifier(reuseId)
        if anView == nil {
            anView = MKAnnotationView(annotation: annotation, reuseIdentifier: reuseId)
            anView.canShowCallout = true
            
        }
        else {
            anView.annotation = annotation
        }
        
        var button = UIButton.buttonWithType(UIButtonType.DetailDisclosure) as! UIButton
        anView.rightCalloutAccessoryView = button
        
        let customAnnotation = annotation as! CustomAnnotation
        
        if (customAnnotation.image != nil) {
            anView.image = customAnnotation.image!
            
        }
        else {
            
            anView.image = UIImage(named: "defaultpin.png")
            //set default image
        }
        
        return anView
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
}

