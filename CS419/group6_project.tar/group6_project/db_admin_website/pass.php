<?php
$db_pass = "TRnZRUZu8qfyPm66";
?>