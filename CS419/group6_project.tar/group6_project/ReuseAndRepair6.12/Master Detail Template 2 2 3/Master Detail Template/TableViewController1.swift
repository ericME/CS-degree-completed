//
//  TableViewController1.swift
//  Master Detail Template
//
//  Created by Lacie Wilson on 5/19/15.
//  Copyright (c) 2015 lacieapp. All rights reserved.
//

import UIKit
import CoreData
import MapKit

class TableViewController1: UITableViewController  {
    
    var managedObjectContext: NSManagedObjectContext? = nil

    var dataPassed: NSDictionary!
    var itemsReceived : NSArray = []
    
    var location: CLLocation!
    
    var locationManager: CLLocationManager = {
        let _locationManager = CLLocationManager()
        _locationManager.requestWhenInUseAuthorization()
        return _locationManager
        }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.startUpdatingLocation()

        var jsonResult: NSDictionary
        var appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        var context: NSManagedObjectContext = appDel.managedObjectContext!
        let url = NSURL(string: "http://web.engr.oregonstate.edu/~rousee/CS419/api/?CategoryAll")
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithURL(url!, completionHandler: { (data, response, error) -> Void in
            
            if error != nil {
                
                println(error)
                
            } else {
                
                let jsonResult = NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions.MutableContainers, error: nil) as! NSDictionary
                
                if jsonResult.count > 0 {
                    
                    if let categories = jsonResult["Categories"] as? NSArray {
                        
                        for category in categories {
                            
                            if let cat = category["id"] as? String {
                                
                                var dat = self.dataPassed["id"] as? String
                                
                                if cat == dat {

                                    self.itemsReceived = category["items"] as! NSArray!
                                }
                            }
                            
                        }
                        
                    }

                    dispatch_async(dispatch_get_main_queue()){
                
                        self.tableView.reloadData()
                    }
                }
            }
            
        })
        
        task.resume()
    }
    
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "showBusinessList" {
            
            if let indexPath = self.tableView.indexPathForSelectedRow() {

                var destinationViewController = segue.destinationViewController as! TableViewController2
                destinationViewController.title = itemsReceived[indexPath.row] as? String
               
                var categoryId = dataPassed["id"] as! String
                let subCategoryId = itemsReceived.indexOfObject(itemsReceived[indexPath.row]) + 1
                var subCategoryIdString = String(subCategoryId)

                let location = locationManager.location!

                destinationViewController.currentLocation = location
   
                destinationViewController.passedCategoryId = categoryId
                destinationViewController.passedSubCategoryId = subCategoryIdString
               
            }
            
        }
    }

    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete method implementation.
        // Return the number of rows in the section.
        return itemsReceived.count
    }
    
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("subcells", forIndexPath: indexPath) as! UITableViewCell
        
        cell.textLabel!.text = itemsReceived[indexPath.row] as? String
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        
        return cell
    }
    
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
    // Return NO if you do not want the specified item to be editable.
    return true
    }
    */
    
    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
    if editingStyle == .Delete {
    // Delete the row from the data source
    tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
    } else if editingStyle == .Insert {
    // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }
    }
    */
    
    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
    
    }
    */
    
    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
    // Return NO if you do not want the item to be re-orderable.
    return true
    }
    */
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    }
    */
    
}
