//
//  AboutPageViewController.swift
//  Corvallis Reuse and Repair Directory
//
//  Created by Aryan Aziz on 6/11/15.
//  Copyright (c) 2015 lacieapp. All rights reserved.
//

import UIKit

class AboutPageViewController: UIViewController {
    @IBAction func acceptButton(sender: AnyObject) {
        if let url = NSURL(string: "http://site.republicservices.com/site/corvallis-or/en/documents/corvallisrecycledepot.pdf") {
            UIApplication.sharedApplication().openURL(url)
        }
    }
    @IBAction func curbsideButton(sender: AnyObject) {
        if let url = NSURL(string: "http://site.republicservices.com/site/corvallis-or/en/documents/detailedrecyclingguide.pdf") {
            UIApplication.sharedApplication().openURL(url)
        }
    }
}
