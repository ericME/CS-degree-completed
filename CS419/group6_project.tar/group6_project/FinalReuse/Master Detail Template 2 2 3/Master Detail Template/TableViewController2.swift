//
//  TableViewController2.swift
//  Master Detail Template
//
//  Created by Lacie Wilson on 5/26/15.
//  Copyright (c) 2015 lacieapp. All rights reserved.
//

import UIKit
import CoreData
import MapKit

class TableViewController2: UITableViewController, CLLocationManagerDelegate {

    var passedCategoryId: String = ""
    var passedSubCategoryId: String = ""
    
    var businessList : [AnyObject] = []
    var businessAddressList : [AnyObject] = []
    var businessWebsiteList : [AnyObject] = []
    var businessPhoneList : [AnyObject] = []
    var businessZipList : [AnyObject] = []
    
    var currentLocation: CLLocation!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        dispatch_async(dispatch_get_main_queue()) {
            
            var jsonResult: NSDictionary
            var appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
            var context: NSManagedObjectContext = appDel.managedObjectContext!
            let url = NSURL(string: "http://web.engr.oregonstate.edu/~rousee/CS419/api?BusinessesByCatID=\(self.passedCategoryId)&SubcategoryID=\(self.passedSubCategoryId)")
            let session = NSURLSession.sharedSession()
            let task = session.dataTaskWithURL(url!, completionHandler: { (data, response, error) -> Void in
                
                if error != nil {
                    
                    println(error)
                    
                } else {
                     dispatch_async(dispatch_get_main_queue()) {
                    let jsonResult = NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions.MutableContainers, error: nil) as! NSDictionary
    
                    if jsonResult.count > 0 {
                        
                        if let businesses = jsonResult["Businesses"] as? NSArray {
                            
                            for business in businesses {
                                
                                if let businessName = business["name"] as? String {
                                    
                                    self.businessList.append(businessName)
                                    
                                }
                                
                                if let businessAddress = business["address"] as? String {
                                    
                                    self.businessAddressList.append(businessAddress)
                                    
                                }
                                if let businessPhone = business["phone"] as? String {
                                    
                                    self.businessPhoneList.append(businessPhone)
                                    
                                }
                                if let businessWebsite = business["url"] as? String {
                                    
                                    self.businessWebsiteList.append(businessWebsite)
                                    
                                }
                                if let businessZip = business["zip"] as? String {
                                    
                                    self.businessZipList.append(businessZip)
                                    
                                }
                            }
                        }
                        
                        
                        dispatch_async(dispatch_get_main_queue()){
                            
                            self.tableView.reloadData()
                        }
                    }
                    }}
                
            })
            
            task.resume()
            
        }
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "showBusinessDetail" {
            
            if let indexPath = self.tableView.indexPathForSelectedRow() {
                
                var destinationViewController = segue.destinationViewController as! BusinessTableView
                destinationViewController.title = businessList[indexPath.row] as? String
                
                var passedBusinessTitle = businessList[indexPath.row].description
                
                var passedPhone = businessPhoneList[indexPath.row].description
                destinationViewController.receivedPhone = passedPhone
                
                var passedWebsite = businessWebsiteList[indexPath.row].description
                destinationViewController.receivedWebsite = passedWebsite
                
                var passedZip = businessZipList[indexPath.row].description
                destinationViewController.receivedZip = passedZip
                
                destinationViewController.receivedBusinessTitle = passedBusinessTitle
                var passedBusinessAddresses = businessAddressList
                destinationViewController.receivedBusinessAddresses = passedBusinessAddresses
                var passedBusinessAddress = businessAddressList[indexPath.row].description
                destinationViewController.receivedBusinessAddress = passedBusinessAddress
                
            }
            
        }
        if segue.identifier == "showMap" {
            
            var destinationViewController = segue.destinationViewController as! ViewControllerMap
            var passedBusinessAddresses = businessAddressList
            var passedBusinessNames = businessList

            var passedZip = businessZipList
            destinationViewController.receivedZip = passedZip
            
            destinationViewController.receivedBusinessAddresses = passedBusinessAddresses
            destinationViewController.receivedBusinessNames = passedBusinessNames
        }
        
        
    }
    
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete method implementation.
        // Return the number of rows in the section.
        return businessList.count
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCellWithIdentifier("businessCell", forIndexPath: indexPath) as! UITableViewCell
        
        var businessListArray = businessList as NSArray
        var number = businessListArray.indexOfObject(businessListArray[indexPath.row]) + 1
        var numberString = String(number)
        cell.detailTextLabel?.text = " "
        cell.textLabel!.text = businessList[indexPath.row] as? String
        cell.accessoryType = UITableViewCellAccessoryType.DisclosureIndicator
        var imageName = UIImage(named: numberString)
        cell.imageView?.image = imageName

        var distanceInMiles: Double
        var distanceInMilesString: String = ""
        let location = "\(businessAddressList[indexPath.row]) \(businessZipList[indexPath.row])"
        
        var geocoder:CLGeocoder = CLGeocoder()
        geocoder.geocodeAddressString(location, completionHandler: {(placemarks, error) -> Void in
            
            if((error) != nil){
                
                println("Error", error)
            }
                
            else if let placemark = placemarks?[0] as? CLPlacemark {
                
                dispatch_async(dispatch_get_main_queue()) {

                
                var placemark:CLPlacemark = placemarks[0] as! CLPlacemark
                var coordinates:CLLocationCoordinate2D = placemark.location.coordinate
                
                var destination: CLLocation = CLLocation(latitude: coordinates.latitude, longitude: coordinates.longitude)
                
                let distance = destination.distanceFromLocation(self.currentLocation)
                let distanceInMiles = distance * 0.000621371
                var distanceInMilesRounded = round(100.0 * distanceInMiles) / 100.0
                var distanceInMilesString = "\(distanceInMilesRounded) miles"
                
                cell.detailTextLabel?.text = distanceInMilesString

                }
            }
            
        })
        
        return cell
        
    }
    
    
    
    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
    // Return NO if you do not want the specified item to be editable.
    return true
    }
    */
    
    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
    if editingStyle == .Delete {
    // Delete the row from the data source
    tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
    } else if editingStyle == .Insert {
    // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }
    }
    */
    
    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
    
    }
    */
    
    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
    // Return NO if you do not want the item to be re-orderable.
    return true
    }
    */
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    }
    */
    
}
