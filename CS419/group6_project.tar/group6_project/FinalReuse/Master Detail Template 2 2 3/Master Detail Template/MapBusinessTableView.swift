//
//  MapBusinessTableView.swift
//  Corvallis Reuse and Repair Directory
//
//  Created by Aryan Aziz on 6/11/15.
//  Copyright (c) 2015 lacieapp. All rights reserved.
//

import UIKit
import CoreData
import MapKit
import AddressBook


class MapBusinessTableView: UITableViewController {
    
    var receivedBusinessName: String!
    var receivedBusinessTitle: String!
    var receivedBusinessAddress: String!
    var receivedZip: String!
    var receivedPhone: String!
    var receivedWebsite: String!
    var receivedHours: String!
    
    var coords: CLLocationCoordinate2D?
    
    @IBOutlet var directionsLabel: UIButton!
    @IBOutlet var businessNameLabel: UILabel!
    @IBOutlet var businessAddressLabel: UILabel!
    @IBOutlet var businessHoursLabel: UILabel!
    @IBOutlet var errorLabel: UIButton!
    @IBOutlet var phone: UIButton!
    @IBOutlet var website: UIButton!
    @IBAction func websiteButton(sender: AnyObject) {
        if let url = NSURL(string: "http://\(receivedWebsite)") {
            UIApplication.sharedApplication().openURL(url)
        }
    }
    
    @IBAction func phoneButton(sender: AnyObject) {
        if let url = NSURL(string: "tel://\(receivedPhone)") {
            UIApplication.sharedApplication().openURL(url)
        }
    }
    @IBAction func directionsPressed(sender: AnyObject) {
        let geoCoder = CLGeocoder()
        println("map address: \(receivedBusinessAddress) \(receivedZip)")
        let addressString = "\(receivedBusinessAddress) \(receivedZip)"
        //let addressString = receivedBusinessAddress
        geoCoder.geocodeAddressString(addressString, completionHandler:
            {(placemarks: [AnyObject]!, error: NSError!) in
                
                if error != nil {
                    //self.errorLabel.setTitle = "Address"
                    self.directionsLabel.setTitle("Directions Unavailable", forState: UIControlState.Normal)
                } else if placemarks.count > 0 {
                    let placemark = placemarks[0] as! CLPlacemark
                    let location = placemark.location
                    
                    self.coords = location.coordinate
                    let addressDict =
                    [kABPersonAddressStreetKey as NSString: self.receivedBusinessAddress,
                        kABPersonAddressZIPKey: self.receivedZip
                    ]
                    let place = MKPlacemark(coordinate: self.coords!, addressDictionary: addressDict)
                    let mapItem = MKMapItem(placemark: place)
                    println("map item: \(mapItem)")
                    let options = [MKLaunchOptionsDirectionsModeKey:
                    MKLaunchOptionsDirectionsModeDriving]
                    
                    mapItem.openInMapsWithLaunchOptions(options)
                    
                }
        })
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var jsonResult: NSDictionary
        var appDel: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        var context: NSManagedObjectContext = appDel.managedObjectContext!
        let url = NSURL(string: "http://web.engr.oregonstate.edu/~rousee/CS419/api?BusinessAll")
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithURL(url!, completionHandler: { (data, response, error) -> Void in
            
            if error != nil {
                
                println(error)
                
            } else {
                 dispatch_async(dispatch_get_main_queue()) {
                let jsonResult = NSJSONSerialization.JSONObjectWithData(data, options: NSJSONReadingOptions.MutableContainers, error: nil) as! NSDictionary
                
                if jsonResult.count > 0 {
                    
                    if let businesses = jsonResult["Businesses"] as? NSArray {
                        
                        for business in businesses {
                            if let businessName = business["name"] as? String {
                                if let businessAddress = business["address"] as? String {
                                    if let businessHours = business["hours"] as? String {
                                        if let businessZip = business["zip"] as? String{
                                        if businessName == self.receivedBusinessTitle {
                                            
                                            
                                            if let businessPhone = business["phone"] as? String {
                                                self.receivedPhone = business["phone"] as! String
                                            }
                                            if let businessUrl = business["url"] as? String {
                                                self.receivedWebsite = businessUrl
                                            }
                                            
                                            
                                            
                                            
                                            dispatch_async(dispatch_get_main_queue()) {
                                                //self.receivedPhone = business["phone"] as? String
                                                //self.receivedWebsite = business["website"] as? String
                                                if businessName != "" {
                                                    self.businessNameLabel.text = self.receivedBusinessTitle
                                                } else {
                                                    self.businessNameLabel.text = "None Given"
                                                }
                                                if businessAddress != "" {
                                                    self.businessAddressLabel.text = businessAddress
                                                    self.receivedBusinessAddress = businessAddress
                                                } else {
                                                    self.businessAddressLabel.text = "None Given"
                                                }
                                                if businessZip != "" {
                                                    self.receivedZip = businessZip
                                                } else {
                                                    self.receivedZip = ""
                                                }
                                                if businessHours != "" {
                                                    self.businessHoursLabel.text = businessHours
                                                } else {
                                                    self.businessHoursLabel.text = "None Given"
                                                }
                                                if self.receivedPhone != "" {
                                                    self.phone.setTitle(self.receivedPhone, forState: UIControlState.Normal)
                                                } else {
                                                    
                                                    self.phone.setTitle("None Given", forState: UIControlState.Normal)
                                                }
                                                if self.receivedWebsite != "" {
                                                    self.website.setTitle(self.receivedWebsite, forState: UIControlState.Normal)
                                                } else {
                                                    self.website.setTitle("None Given", forState: UIControlState.Normal)
                                                }
                                            }
                                        }
                                    }
                                    }}
                            }
                        }
                        }
                    }
                    
                }
            }
            
        })
        
        task.resume()
        
        
        
        // Do any additional setup after loading the view.
    }

}
