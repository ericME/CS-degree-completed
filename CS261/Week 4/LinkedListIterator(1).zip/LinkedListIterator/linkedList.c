#include "linkedList.h"
#include "assert.h"
#include <stdlib.h>
#include <stdio.h>




/* Double Link*/
struct DLink {
	TYPE value;
	struct DLink * next;
	struct DLink * prev;
};

/* Double Linked List with Head and Tail Sentinels  */

struct linkedList{
	int size;
	struct DLink *frontSentinel;
	struct DLink *backSentinel;
};



struct bag{/*Wrapper for bag*/
	struct linkedList* lst;/*List implementing the bag*/
};

/*
	initList
	param lst the linkedList
	pre: lst is not null
	post: lst size is 0
*/

void _initList (struct linkedList *lst) {
   /* create the sentinels */
   lst->frontSentinel = (struct DLink *) malloc(sizeof(struct DLink));
   lst->backSentinel = (struct DLink *) malloc (sizeof(struct DLink));
   assert (lst->frontSentinel != 0);
   assert(lst->backSentinel != 0);
   
   lst->frontSentinel->prev = 0;
   lst->frontSentinel->next = lst->backSentinel;
   
   lst->backSentinel->next = 0;
   lst->backSentinel->prev = lst->frontSentinel;
  
   lst->size = 0;
}

/*
 createList
 param: none
 pre: none
 post: frontSentinel and backSentinel reference sentinels
 */

struct linkedList *createLinkedList()
{
	struct linkedList *newList = malloc(sizeof(struct linkedList));
	_initList(newList);
	return(newList);
}

/*
	_addLinkBeforeBefore
	param: lst the linkedList
	param: l the  link to add before
	param: v the value to add
	pre: lst is not null
	pre: l is not null
	post: lst is not empty
*/

/* Adds Before the provided link, l */

void _addLinkBefore(struct linkedList *lst, struct DLink *l, TYPE v)
{
   struct DLink * lnk = (struct DLink *) malloc(sizeof(struct DLink));
   assert(lnk != 0);

	lnk->next = l;
	lnk->prev = l->prev;
	lnk->value = v;
	
	l->prev->next = lnk;
	l->prev = lnk;
   
   	lst->size++;
}


/*
	addFrontList
	param: lst the linkedList
	param: e the element to be added
	pre: lst is not null
	post: lst is not empty, increased size by 1
*/

void addFrontList(struct linkedList *lst, TYPE e)
{

	_addLinkBefore(lst, lst->frontSentinel->next, e);
	
}

/*
	addBackList
	param: lst the linkedList
	pre: lst is not null
	post: lst is not empty
*/

void addBackList(struct linkedList *lst, TYPE e) {
  
  _addLinkBefore(lst, lst->backSentinel, e);
}

/*
	frontList
	param: lst the linkedList
	pre: lst is not null
	pre: lst is not empty
	post: none
*/

TYPE frontList (struct linkedList *lst) {
   assert(!isEmptyList(lst));
   return lst->frontSentinel->next->value;
}

/*
	backList
	param: lst the linkedList
	pre: lst is not null
	pre: lst is not empty
	post: lst is not empty
*/

TYPE backList(struct linkedList *lst)
{
	assert(!isEmptyList(lst));
	return lst->backSentinel->prev->value;
}

/*
	_removeLink
	param: lst the linkedList
	param: l the linke to be removed
	pre: lst is not null
	pre: l is not null
	post: lst size is reduced by 1
*/

void _removeLink(struct linkedList *lst, struct DLink *l)
{

	l->next->prev = l->prev;
	l->prev->next = l->next;
	free(l);
   	lst->size--;
}

/*
	removeFrontList
	param: lst the linkedList
	pre:lst is not null
	pre: lst is not empty
	post: size is reduced by 1
*/

void removeFrontList(struct linkedList *lst) {
   assert(! isEmptyList(lst));
  	
   _removeLink(lst, lst->frontSentinel->next);
}

/*
	removeBackList
	param: lst the linkedList
	pre: lst is not null
	pre:lst is not empty
	post: size reduced by 1
*/

void removeBackList(struct linkedList *lst)
{	
	assert(!isEmptyList(lst));

	_removeLink(lst, lst->backSentinel->prev);
}

/*
	isEmptyList
	param: lst the linkedList
	pre: lst is not null
	post: none
*/

int isEmptyList(struct linkedList *lst) {
   return (lst->frontSentinel->next == lst->backSentinel);
   //or return(lst->size == 0)
}


/* Function to print list
 Pre: lst is not null
 */
void _printList(struct linkedList* lst)
{
	struct DLink *lnk = lst->frontSentinel->next;
	
	while(lnk != lst->backSentinel)
	{
		printf("%d->", lnk->value);
		lnk = lnk->next;
	}
	
	printf("\n");
}

/* Iterative implementation of contains() 
 Pre: lst is not null
 */

void addList(struct linkedList *lst, TYPE v)
{
	assert(lst != 0);
	addBackList(lst, v);
}

/* Iterative implementation of contains() 
 Pre: lst is not null
 pre: list is not empty
 */
int containsList (struct linkedList *lst, TYPE e) {
	struct DLink *current;

	assert(lst != 0);
	assert(!isEmptyList(lst));
	current = lst->frontSentinel->next; /* Initialize current */
	while(current != lst->backSentinel)
	{
		if(EQ(current->value,e))
			return 1;
		current=current->next;
	}
	return 0;
}

/* Iterative implementation of remove() 
 Pre: lst is not null
 pre: lst is not empty
 */
void removeList (struct linkedList *lst, TYPE e) {
	assert(lst != 0);
	assert(!isEmptyList(lst));
	struct DLink *current;
	current = lst->frontSentinel->next; /* Initialize current */
	while(current != lst->backSentinel)
	{
		if(EQ(current->value,e))
		{
			_removeLink(lst,current);
			break; /* Only remove one copy of it */
		}
		current=current->next;
	}
}

/* Iterator Interface */

struct linkedListIter {
	struct DLink *cur;
	struct linkedList *lst;
};

/* Initialize an iterator */

void  initlinkedListIter (struct linkedList *lst, struct linkedListIter *itr) {
	itr->lst = lst;
	itr->cur = itr->lst->frontSentinel;
}

/* create a new iterator struct and return it */

struct linkedListIter *createlinkedListIter(struct linkedList *lst){
	struct linkedListIter *newItr = malloc(sizeof(struct linkedListIter));
	assert(newItr != 0);
	initlinkedListIter(lst, newItr);
	return(newItr);
}

 /* Determines if there are more values in the collection and if so, returns true.  It also
  * sets up for the subsequent call to 'next' by making cur point to the next value in the collection.
  */
int hasNextlinkedListIter (struct linkedListIter *itr) {

	if(itr->cur->next != itr->lst->backSentinel)
	{
		itr->cur = itr->cur->next;
		return(1);
	}
	else return (0);

}

/* returns the next value in the collection */
TYPE nextlinkedListIter (struct linkedListIter *itr) {
	return(itr->cur->value);
}

/* removes the last value returned by 'next'
 * Notice that we use a tmp to ensure that the following
 * calls to hasNext and next are correct after removal of the
 * current link.*/
void removelinkedListIter (struct linkedListIter *itr) {
	struct DLink *tmp = itr->cur;
	itr->cur = itr->cur->prev;
	_removeLink(itr->lst, tmp);
}





/*Bag Wrapper Interface*/
struct bag *createBag()
{
	struct bag *myBag = malloc(sizeof(struct bag));
	myBag->lst = createLinkedList();
	return myBag;
}
void addToBag(struct bag* b, TYPE val)
{
	addList(b->lst, val);
}
void removeFromBag(struct bag* b, TYPE val)
{
	removeList(b->lst, val);
}
int containsBag(struct bag* b, TYPE val)
{
	return(containsList(b->lst, val));
}
int isEmptyBag(struct bag* b)
{
	return(isEmptyList(b->lst));
}

void printBag(struct bag *b)
{
	_printList(b->lst);
}
