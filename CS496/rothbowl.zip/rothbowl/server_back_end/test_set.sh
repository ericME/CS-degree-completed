#!/bin/bash
echo "---> full listing via GET"
echo "--------------------------"
curl rothbowl.herokuapp.com/api

echo "---> player listing via GET"
echo "--------------------------"
curl rothbowl.herokuapp.com/api/player/0
curl rothbowl.herokuapp.com/api/player

echo "---> bowl listing via GET"
echo "--------------------------"
curl rothbowl.herokuapp.com/api/bowl/0
curl rothbowl.herokuapp.com/api/bowl

echo "---> blank POST"
echo "--------------------------"
curl --data ""  rothbowl.herokuapp.com/api

echo "---> player add via POST"
echo "--------------------------"
curl --data "player-add=True&fname=Eric&lname=Rouse&winners=Oregon,Washington&natl-champ=Oregon&scores=33,66,77&points=5" rothbowl.herokuapp.com/api/

echo "---> another add via POST"
echo "--------------------------"
curl --data "player-add=True&fname=Ted&lname=Bundy&winners=State,Minnesota&natl-champ=Quebec&scores=1,2,3&points=5" rothbowl.herokuapp.com/api/

echo "---> bowl add via POST"
echo "--------------------------"
curl --data "bowl-add=True&name=Sugar&favorite=FSU&underdog=Kent&predicted-spread=7&fav-score=32&und-score=22&tot-score=52&winner=FSU&loser=Kent&actual-spread=10&game-is-played=True" rothbowl.herokuapp.com/api/

echo "---> player put via POST"
echo "--------------------------"
curl --data "put=True&player-put=True&put-id=12&fname=put&lname=test" rothbowl.herokuapp.com/api

echo "---> bowl put via POST"
echo "--------------------------"
curl --data "put=True&bowl-put=True&put-id=12&name=put%20test" rothbowl.herokuapp.com/api

echo "---> patch bowl via POST"
echo "--------------------------"
curl --data "patch=True&member-type=bowl&member-id=12&key=name&val=super"  rothbowl.herokuapp.com/api
curl --data "patch=True&member-type=bowl&member-id=12&key=predicted%20spread&val=12000"  rothbowl.herokuapp.com/api

echo "---> patch player via POST"
echo "--------------------------"
curl --data "patch=True&member-type=player&member-id=12&key=name&val=Sea%20Hawks"  rothbowl.herokuapp.com/api
curl --data "patch=True&member-type=player&member-id=12&key=winners&val=Hawks"  rothbowl.herokuapp.com/api

echo "---> delete player via POST"
echo "--------------------------"
curl --data "delete=True&member-type=player&member-id=12"  rothbowl.herokuapp.com/api

echo "---> scan bowl list via GET"
echo "--------------------------"
curl  rothbowl.herokuapp.com/api/scan

echo "---> delete bowl via POST"
echo "--------------------------"
curl --data "delete=True&member-type=bowl&member-id=12"  rothbowl.herokuapp.com/api

echo "---> scan bowl list again via GET"
echo "--------------------------"
curl  rothbowl.herokuapp.com/api/scan