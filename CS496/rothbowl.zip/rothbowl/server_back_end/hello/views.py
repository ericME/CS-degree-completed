from django.shortcuts import render
from django.http import HttpResponse
from django import forms
import time
import os
import redis

from .models import Greeting

PATH = os.path.dirname(__file__) + '/templates/'
master_dict = {
        'current_name': "",
        'current_secret': "",
        'current_check' : "",
        'current_r1_check':"",
        'current_r2_check':"",
        'current_r3_check':"",
        'current_color':"#b1ad35",
        'current_disable':""
        }
radio_list = ['current_r1_check', 'current_r2_check', 'current_r3_check']
#important redis stuff
redis_url = os.getenv('REDISTOGO_URL', 'redis://localhost:6379')
my_redis = redis.from_url(redis_url)

class DjForm(forms.Form):
    your_name = forms.CharField(label='Your name', max_length = 100)
    your_secret = forms.CharField(label='')


# Create your views here.
def index(request):
    return HttpResponse('ROTHBOWL Landing Page<br>' + time.strftime('%X %x %Z'))

def testapi(request):

    return render(request, os.path.dirname(__file__) + '/templates/testapi.html',
            master_dict, content_type="text/html")

def player_add(fname, lname, winners, high_stakes, natl_champ, champ_score, points):
    my_redis.hmset('player:' + my_redis.get('player_count'), {'name': str(fname+" "+lname), 'winners':winners,\
        'high_stakes':high_stakes, 'natl_champ':natl_champ, 'champ_score':champ_score, 'points':points})
    my_redis.incr('player_count')

def player_put(put_id, fname, lname, winners, high_stakes, natl_champ, champ_score, points):
    my_redis.hmset('player:' + put_id, {'name': str(fname+" "+lname), 'winners':winners,\
        'high_stakes':high_stakes, 'natl_champ':natl_champ, 'champ_score':champ_score, 'points':points})

def member_del(member_type, id_number):
    if id_number == "":
        if member_type == "bowl":
            id_number = my_redis.get('bowl_count')
        elif member_type == "player":
            id_number = my_redis.get('player_count')

    my_redis.delete("{}:{}".format(member_type, id_number))
    if member_type == "bowl":
        my_redis.srem('bowl_set', "{}:{}".format(member_type, id_number))


def member_update(member_type, id_number, key, val):
    my_redis.hset("{}:{}".format(member_type, id_number), key, val)

def bowl_add(name, favorite, underdog, pred_spread, fav_score, und_score, tot_score, winner,\
    loser, actual_spread, game_is_played):
    my_redis.hmset('bowl:' + my_redis.get('bowl_count'), {'name':name, 'favorite':favorite, 'underdog':underdog,\
        'predicted spread':pred_spread, 'favorite actual score':fav_score, 'underdog actual score':und_score,\
        'total score':tot_score, 'winner':winner})
    my_redis.sadd('bowl_set', 'bowl:' + my_redis.get('bowl_count'))
    my_redis.incr('bowl_count')


def bowl_put(put_id, name, favorite, underdog, pred_spread, fav_score, und_score, tot_score, winner,\
    loser, actual_spread, game_is_played):
    my_redis.hmset('bowl:' + put_id, {'name':name, 'favorite':favorite, 'underdog':underdog,\
        'predicted spread':pred_spread, 'favorite actual score':fav_score, 'underdog actual score':und_score,\
        'total score':tot_score, 'winner':winner})
    my_redis.sadd('bowl_set', 'bowl:' + put_id)

def allPlayers():
    string = ""
    for i in range(int(my_redis.get('player_count'))):
        string += "{}:{}\n".format("player", i)
        string += str(my_redis.hscan("{}:{}".format("player", i), 0))[5:-1]
        string += "\n"
    return string

def onePlayer(player_number):
    string = str(my_redis.hscan("{}:{}".format("player", player_number), 0))[5:-1]
    string += "\n"
    return string

def allBowls():
    string = ""
    for i in range(int(my_redis.get('bowl_count'))):
        string += "{}:{}\n".format("bowl", i)
        string += str(my_redis.hscan("{}:{}".format("bowl", i), 0))[5:-1]
        string += "\n"
    return string

def scanBowlList():
    return "Scan: " + str(my_redis.sscan('bowl_set'))[5:-1] + "\n"

def oneBowl(bowl_number):
    string = str(my_redis.hscan("{}:{}".format("bowl", bowl_number), 0))[5:-1]
    string += "\n"
    return string

def reset_numbers():
    my_redis.set('player_count', 0)
    my_redis.set('bowl_count', 0)

def user_data(user, data1, data2, data3, req):
    if req.lower() == "delete":
        my_redis.delete("{}".format(user))
        return "Deleted: " + user
    elif req.lower() == "get":
        return str(my_redis.hscan("{}".format(user), 0))[5:-1]
    elif req.lower() == "put":
        my_redis.hmset(user, {'username':user, 'data1': data1, 'data2': data2, 'data3': data3})
        return str(my_redis.hscan("{}".format(user), 0))[5:-1]
    elif req.lower() == "reset":
        my_redis.set('user_count', 0)
        return "RESET USER COUNT"

def api(request):
    string = ""
    #get method, get a player, get a bowl or get all of them
    #GET
    if request.method == 'GET':
        req_player = request.path.find("player")
        req_bowl = request.path.find("bowl")
        req_path = request.path.find("path")
        req_count = request.path.find("count")
        req_scan = request.path.find("scan")
        if req_path != -1:
            string = request.path[req_path:]
        elif req_scan != -1:
            string = scanBowlList()
        elif req_count != -1:
            string = "bowls count: " + my_redis.get('bowl_count') + "\n"\
            + "player count: " + my_redis.get('player_count') + "\n"
        elif req_player != -1:
            req_num = request.path[req_player:].find("/")
            if req_num != -1:
                string += onePlayer(request.path[req_player + req_num + 1:])
            else:
                string += allPlayers()
        elif req_bowl != -1:
            req_num = request.path[req_bowl:].find("/")
            if req_num != -1:
                string += oneBowl(request.path[req_bowl + req_num + 1:])
            else:
                string += allBowls()
        else:
            string += allBowls()
            string += allPlayers()
        return HttpResponse(string)
    #post method, add players, bowls; delete them; update their info
    if request.method == 'POST':
        #DELETE
        if request.POST.get('delete', "False") == "True":
            member_del(request.POST.get('member-type', ""), request.POST.get('member-id', ""))
            string = "Member Removed, type: " + request.POST.get('member-type', "") + " id: " + request.POST.get('member-id', "")
            if request.POST.get('member-type', "") == 'player':
                string += " > " + onePlayer(request.POST.get('member-id', ""))
            elif request.POST.get('member-type', "") == 'bowl':
                string += " > " + oneBowl(request.POST.get('member-id', ""))
            return HttpResponse(string)
        #PATCH
        elif request.POST.get('patch', "False") == "True":
            member_update(request.POST.get('member-type', ""), request.POST.get('member-id', ""), request.POST.get('key', ""), request.POST.get('val', ""))
            string = "Member Updated, type: " + request.POST.get('member-type', "") + " id: " + request.POST.get('member-id', "")
            if request.POST.get('member-type', "") == 'player':
                string += " > " + onePlayer(request.POST.get('member-id', ""))
            elif request.POST.get('member-type', "") == 'bowl':
                string += " > " + oneBowl(request.POST.get('member-id', ""))

            return HttpResponse(string)
        #PUT
        elif request.POST.get('put', "False") == "True":
            if request.POST.get('player-put', "False") == "True":
                player_put(request.POST.get('put-id', my_redis.get('player_count')), request.POST.get('fname', ""), request.POST.get('lname', ""), request.POST.get('winners', "[]"),\
                    request.POST.get('high-stakes', ""), request.POST.get('natl-champ', ""), request.POST.get('scores', "[]"),\
                    request.POST.get('points', 0))
                string = "Player puted: " + onePlayer(request.POST.get('put-id', int(my_redis.get('player_count'))-1))

            elif request.POST.get('bowl-put', "False") == "True":
                bowl_put(request.POST.get('put-id', my_redis.get('bowl_count')), request.POST.get('name', ""), request.POST.get('favorite', ""), request.POST.get('underdog', ""),\
                    request.POST.get('predicted-spread', ""), request.POST.get('fav-score', ""), request.POST.get('und-score', ""),\
                    request.POST.get('tot-score', ""), request.POST.get('winner', ""), request.POST.get('loser', ""),\
                    request.POST.get('actual-spread', ""), request.POST.get('game-is-played', ""))
                string = "Bowl puted: " + oneBowl(request.POST.get('put-id', int(my_redis.get('player_count'))-1))

            return HttpResponse(string)
        #POST
        else:
            if request.POST.get('user-data', "False") == "True":
                string = user_data(request.POST.get('username'), request.POST.get('data1'), request.POST.get('data2'), request.POST.get('data3'), request.POST.get('request_type'))

            elif request.POST.get('player-add', "False") == "True":
                player_add(request.POST.get('fname', ""), request.POST.get('lname', ""), request.POST.get('winners', "[]"),\
                    request.POST.get('high-stakes', ""), request.POST.get('natl-champ', ""), request.POST.get('scores', "[]"),\
                    request.POST.get('points', 0))
                string = "Player Added: " + onePlayer(str(int(my_redis.get('player_count'))-1))

            elif request.POST.get('bowl-add', "False") == "True":
                bowl_add(request.POST.get('name', ""), request.POST.get('favorite', ""), request.POST.get('underdog', ""),\
                    request.POST.get('predicted-spread', ""), request.POST.get('fav-score', ""), request.POST.get('und-score', ""),\
                    request.POST.get('tot-score', ""), request.POST.get('winner', ""), request.POST.get('loser', ""),\
                    request.POST.get('actual-spread', ""), request.POST.get('game-is-played', ""))
                string = "Bowl Added: " + oneBowl(str(int(my_redis.get('bowl_count'))-1))

            return HttpResponse(string)

def any(request):
    return HttpResponse('that url doesn\'t work')
